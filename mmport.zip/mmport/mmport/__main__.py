import sys

if "--serve" in sys.argv:
    from .web import serve
    sys.exit(serve())
from .cli import main
sys.exit(main())

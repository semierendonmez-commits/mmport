"""
Yerel web arayuzu — yalnizca standart kutuphane.

Tarayicida acilir, git URL'si ya da yerel yol alir, boru hattini arka planda
calistirir ve gunlugu canli akitir. Disari hicbir sey gondermez; her sey
localhost uzerinde calisir.
"""

from __future__ import annotations

import html
import json
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .pipeline import port

STATE = {
    "running": False,
    "lines": [],
    "done": False,
    "ok": False,
    "plugin": None,
    "project": None,
}
LOCK = threading.Lock()


def _log(line: str) -> None:
    with LOCK:
        STATE["lines"].append(str(line))


def _run(source: str, out: str, strict: bool, do_build: bool) -> None:
    try:
        res = port(source, Path(out) if out else None,
                   strict=strict, do_build=do_build, log=_log)
        with LOCK:
            STATE["ok"] = res.ok
            STATE["plugin"] = str(res.plugin_path) if res.plugin_path else None
            STATE["project"] = str(res.project_dir) if res.project_dir else None
        _log("")
        _log(res.message)
    except Exception as exc:  # noqa: BLE001
        _log("")
        _log(f"HATA: {exc}")
    finally:
        with LOCK:
            STATE["running"] = False
            STATE["done"] = True


PAGE = """<!doctype html>
<meta charset="utf-8">
<title>mmport</title>
<style>
  :root { --fg:#e8e8e8; --bg:#0b0b0b; --dim:#6a6a6a; --line:#242424; --hi:#fff; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--fg);
         font:13px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace; }
  main { max-width:900px; margin:0 auto; padding:40px 24px 80px; }
  h1 { font-size:13px; font-weight:400; letter-spacing:.32em; text-transform:uppercase;
       margin:0 0 4px; }
  .sub { color:var(--dim); margin:0 0 32px; }
  label { display:block; color:var(--dim); margin:18px 0 6px; letter-spacing:.06em; }
  input[type=text] { width:100%; padding:10px 12px; background:#131313; color:var(--fg);
       border:1px solid var(--line); border-radius:0; font:inherit; }
  input[type=text]:focus { outline:none; border-color:#4a4a4a; }
  .row { display:flex; gap:24px; align-items:center; margin:20px 0 4px; color:var(--dim); }
  .row label { margin:0; display:flex; gap:8px; align-items:center; cursor:pointer; }
  button { margin-top:22px; padding:11px 26px; background:var(--fg); color:#000;
       border:0; font:inherit; letter-spacing:.14em; text-transform:uppercase; cursor:pointer; }
  button:disabled { background:#2a2a2a; color:#666; cursor:default; }
  pre { margin:30px 0 0; padding:18px; background:#080808; border:1px solid var(--line);
       max-height:60vh; overflow:auto; white-space:pre-wrap; word-break:break-word;
       color:#c8c8c8; font-size:12px; }
  .ok { color:var(--hi); } .bad { color:#ff8b6b; }
  .hint { color:var(--dim); margin-top:26px; border-top:1px solid var(--line); padding-top:16px; }
</style>
<main>
  <h1>mmport</h1>
  <p class="sub">VCV Rack &rarr; MetaModule .mmplugin</p>

  <label for="src">Kaynak &mdash; git URL, yerel dizin ya da .zip</label>
  <input type="text" id="src" placeholder="https://github.com/gosub/forsitan-modulare" autofocus>

  <label for="out">Cikti dizini (bos birakilabilir)</label>
  <input type="text" id="out" placeholder="~/mmport-out/&lt;slug&gt;-metamodule">

  <div class="row">
    <label><input type="checkbox" id="strict" checked> yalnizca sorunsuz calisacaklar</label>
    <label><input type="checkbox" id="build" checked> derle</label>
  </div>

  <button id="go">Portla</button>
  <pre id="log">Hazir.</pre>
  <p class="hint">Ilk calistirmada ARM toolchain (~160&nbsp;MB) ve SDK indirilir; sonrakiler hizlidir.
     Her sey ~/.mmport altinda tutulur, sistemin geri kalanina dokunulmaz.</p>
</main>
<script>
let n = 0, timer = null;
const $ = id => document.getElementById(id);
const logEl = $("log");

$("go").onclick = async () => {
  $("go").disabled = true;
  logEl.textContent = "";
  n = 0;
  await fetch("/start", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      source: $("src").value.trim(),
      out: $("out").value.trim(),
      strict: $("strict").checked,
      build: $("build").checked
    })
  });
  timer = setInterval(poll, 400);
};

async function poll() {
  const r = await fetch("/log?from=" + n);
  const d = await r.json();
  if (d.lines.length) {
    logEl.textContent += d.lines.join("\\n") + "\\n";
    n += d.lines.length;
    logEl.scrollTop = logEl.scrollHeight;
  }
  if (d.done) {
    clearInterval(timer);
    $("go").disabled = false;
    logEl.classList.add(d.ok ? "ok" : "bad");
  }
}
</script>
"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="text/html; charset=utf-8"):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/":
            return self._send(200, PAGE)
        if u.path == "/log":
            start = int(parse_qs(u.query).get("from", ["0"])[0])
            with LOCK:
                lines = STATE["lines"][start:]
                payload = {"lines": [html.unescape(x) for x in lines],
                           "done": STATE["done"] and not STATE["running"],
                           "ok": STATE["ok"]}
            return self._send(200, json.dumps(payload), "application/json")
        self._send(404, "not found", "text/plain")

    def do_POST(self):
        if urlparse(self.path).path != "/start":
            return self._send(404, "not found", "text/plain")
        n = int(self.headers.get("Content-Length") or 0)
        req = json.loads(self.rfile.read(n) or b"{}")
        with LOCK:
            if STATE["running"]:
                return self._send(409, json.dumps({"error": "zaten calisiyor"}),
                                  "application/json")
            STATE.update(running=True, lines=[], done=False, ok=False,
                         plugin=None, project=None)
        threading.Thread(
            target=_run,
            args=(req.get("source", ""), req.get("out", ""),
                  bool(req.get("strict", True)), bool(req.get("build", True))),
            daemon=True,
        ).start()
        self._send(200, json.dumps({"started": True}), "application/json")


def serve(port_num: int = 8731, open_browser: bool = True) -> int:
    srv = ThreadingHTTPServer(("127.0.0.1", port_num), Handler)
    url = f"http://127.0.0.1:{port_num}/"
    print(f"mmport: {url}   (durdurmak icin Ctrl-C)")
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nkapatiliyor")
    return 0

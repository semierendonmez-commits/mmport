"""mmport komut satiri arayuzu."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .pipeline import port


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="mmport",
        description="Convert a VCV Rack plugin into a MetaModule .mmplugin file.")
    ap.add_argument("source", help="git URL, .zip/.tar archive, or local directory")
    ap.add_argument("-o", "--out", help="output project directory")
    ap.add_argument("--no-build", action="store_true",
                    help="generate the project only, do not build")
    ap.add_argument("--loose", action="store_true",
                    help="include risky modules too (threads, real-time allocation)")
    ap.add_argument("--analyze-only", action="store_true",
                    help="report only, write nothing")
    ap.add_argument("--serve", action="store_true", help="open the local web interface")
    a = ap.parse_args(argv)

    if a.analyze_only:
        from .analyze import analyze
        from .generate import decide
        from .pipeline import fetch_source
        info = analyze(fetch_source(a.source))
        keep, drop = decide(info, strict=not a.loose)
        print(f"\n{info.plugin_json.get('slug')}: {len(info.modules)} modules\n")
        if info.unmapped_models:
            print(f"  !! {len(info.unmapped_models)} models with no matching source: "
                  f"{', '.join(info.unmapped_models[:8])}"
                  + (" ..." if len(info.unmapped_models) > 8 else "") + "\n")
        for m in sorted(keep, key=lambda m: m.slug.lower()):
            w = sorted({i.kind for i in m.warnings})
            print(f"  OK   {m.slug:<24} " + (f"[{', '.join(w)}]" if w else ""))
        for m, reasons in sorted(drop, key=lambda t: t[0].slug.lower()):
            print(f"  DROP {m.slug:<24} {reasons[0]}")
            for r in reasons[1:]:
                print(f"       {'':<24} {r}")
        return 0

    res = port(a.source, Path(a.out) if a.out else None,
               strict=not a.loose, do_build=not a.no_build)
    print()
    print(res.message)
    return 0 if res.ok else 1


if __name__ == "__main__":
    sys.exit(main())

# mmport

Converts VCV Rack plugins into `.mmplugin` files for the 4ms MetaModule.

Give it a git URL, a `.zip` archive or a local folder. It scans the source,
drops the modules that cannot run on the MetaModule (telling you exactly why),
converts the SVG panels to PNG, generates the project files and builds.

**It never writes to the upstream source.** The port project lands in a
separate folder and references the original tree from outside.

---

## Install

Drag `mmport.app` to your Applications folder and open it. The interface opens
in your browser; the server listens on `127.0.0.1` only and nothing leaves the
machine.

The app is unsigned, so macOS will block it the first time. Either:

```bash
xattr -dr com.apple.quarantine /Applications/mmport.app
```

or right-click the app in Finder > **Open** > **Open**.

Quitting the app (Cmd-Q) also shuts down the server.

### Prerequisites

Python 3 (ships with `xcode-select --install`) plus:

```bash
brew install librsvg      # recommended - small and fast
brew install cmake ninja  # without ninja it falls back to Makefiles, just slower
```

The app adds `/opt/homebrew/bin` and `/usr/local/bin` to its own PATH, so no
further setup is needed.

The ARM toolchain (`arm-none-eabi-gcc` 12.3, the version the SDK requires) and
the MetaModule SDK are downloaded automatically into `~/.mmport`. Nothing else
on the system is touched - delete that folder to remove everything.

## Command line

The same tool is inside the bundle:

```bash
cd /Applications/mmport.app/Contents/Resources/lib

python3 -m mmport https://github.com/gosub/forsitan-modulare
python3 -m mmport ~/Downloads/SomePlugin.zip -o ~/ports/someplugin
python3 -m mmport <source> --analyze-only   # report only, writes nothing
python3 -m mmport <source> --no-build       # generate the project, skip the build
python3 -m mmport <source> --loose          # include risky modules too
python3 -m mmport --serve                   # web interface
```

The first run takes a few minutes because of the toolchain download; later runs
cost only build time.

---

## What it does and does not do

**Does:** fetches the source, runs a portability analysis, removes excluded
modules from both the source list and the `addModel()` calls, converts SVGs to
240 px PNGs, drops unused assets, generates `CMakeLists.txt`, `plugin-mm.json`,
a plugin entry point and a compatibility header, builds, and maps compiler
errors to readable suggestions.

**Does not:** fix code. Moving a module off `std::thread` onto `AsyncThread`, or
turning a real-time allocation into a preallocation, is still manual work. The
tool tells you the exact file and line, and that is all.

The analysis is **heuristic** - regexes and a simple call graph, not a real
compiler front end. False positives and false negatives are possible. If you
disagree with an exclusion, force it through with `--loose` and see what the
compiler says.

---

## Exclusion rules

These come from the MetaModule's actual constraints: plugins run on
`arm-none-eabi-gcc`, without an operating system, on a Cortex-A7.

| Finding | Result | Why |
|---|---|---|
| `network` | excluded | no network stack |
| `host-gui` | excluded | modules cannot be added to or removed from a patch at runtime |
| `file-dialog` | excluded | no native file dialog (the SDK has a file-browser API) |
| `stream` | excluded | libstdc++ stream support is not built |
| `exception` | excluded | `-fno-exceptions` |
| `thread` / `sync` | excluded | no pthread |
| `rt-alloc` (unguarded) | excluded | no heap use in the audio thread |
| `rt-alloc` (sample-rate guarded) | kept | the SDK tolerates the "set up once on first `process()`" pattern |
| `expander` | kept, warned | the module behaves as if no expander is attached; it does not crash |
| `minblep` | kept, patched | the missing specialisation is generated into the compat header |
| `host-read` | kept, informational | reading `APP->scene` only affects drawing |

The `rt-alloc` distinction matters. The tool walks the call graph from
`process()` and checks whether each edge sits inside an `if` that compares the
sample rate. Allocations reachable only through guarded paths are informational;
if even one unguarded path exists, it is a warning.

## Validation

| Plugin | Result |
|---|---|
| forsitan modulare | 18 of 25 modules ported, built, all symbols resolved |
| VCV Fundamental | 39 of 39 passed |
| Bogaudio | 117 of 120 passed |

The three modules excluded from Bogaudio - Analyzer, AnalyzerXL, Ranalyzer -
are **exactly** the ones 4ms excluded by hand in their own official port (all
of them pull in `std::condition_variable` through `analyzer_base`).

On forsitan the tool found two things a manual review had missed: the
`MinBlepGenerator<16,16,float>` specialisation missing from the SDK (it
generated the fix itself), and **tabes** allocating about 5.8 MB per channel in
the audio thread when recording polyphonically.

## Licensing

Ported code keeps its upstream licence - check the `license` field in
`plugin.json`. A licence like the GPL permits porting, but 4ms still recommends
contacting the original author before distributing:
[licensing_permissions.md](https://github.com/4ms/metamodule-plugin-sdk/blob/main/docs/licensing_permissions.md)

## Layout

```
mmport/
  analyze.py    source scanner, model->file mapping, call graph
  assets.py     SVG->PNG, reference-based pruning
  generate.py   CMakeLists / plugin-mm.json / init() / compat header
  toolchain.py  arm-none-eabi-gcc + SDK provisioning
  build.py      cmake driver, error -> suggestion mapping
  pipeline.py   end-to-end flow
  cli.py        command line
  web.py        local interface (stdlib only)
```

Source comments are in Turkish; the interface, logs and generated files are in
English.
